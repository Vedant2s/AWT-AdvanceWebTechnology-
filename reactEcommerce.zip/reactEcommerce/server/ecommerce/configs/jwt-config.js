//use your secret
module.exports={
  secret:"FashionCubeSecret"
}
